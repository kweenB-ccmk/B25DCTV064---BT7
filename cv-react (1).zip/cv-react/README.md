# CV React - Bùi Ánh Quyên
npm install
npm run dev
