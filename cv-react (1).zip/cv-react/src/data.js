// Toàn bộ dữ liệu CV nằm trong các mảng/đối tượng này và được truyền xuống component qua props.
export const navItems = [
  { id: 'about', label: 'Bản thân' },
  { id: 'skills', label: 'Kĩ năng' },
  { id: 'projects', label: 'Dự án' },
  { id: 'hobbies', label: 'Sở thích' },
  { id: 'contact', label: 'Liên hệ với tôi' },
];

export const defaultAvatar =
  "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 200 200'%3E%3Crect width='200' height='200' fill='%23fff4f5'/%3E%3Ccircle cx='100' cy='78' r='38' fill='%23c11f36'/%3E%3Cellipse cx='100' cy='190' rx='62' ry='55' fill='%23c11f36'/%3E%3C/svg%3E";

export const profile = {
  name: 'Bùi Ánh Quyên',
  role: 'Bùi Ánh Quyên — Sinh viên năm hai ngành AIoT, Học viện Công nghệ Bưu chính Viễn thông',
  facts: [
    'Sinh ngày 31/10/2007',
    'Quê quán: Đông Anh, Hà Nội',
    'Sinh viên năm hai ngành AIoT — Học viện Công nghệ Bưu chính Viễn thông',
    'GPA năm nhất: 3.35/4.0',
  ],
  bio: 'Là một sinh viên năm 2 mang trong mình tình yêu mãnh liệt với công nghệ thông minh, tôi luôn bị cuốn hút bởi khả năng biến những ý tưởng trên bản vẽ thành các giải pháp kết nối thực tế. Đam mê lớn nhất của tôi là khám phá cách công nghệ có thể thổi hồn vào vật thể, giúp tối ưu hóa cuộc sống và giải quyết các bài toán của con người. Mong ước của tôi là được rèn luyện trong một môi trường thực tế chuyên nghiệp, nơi tôi có thể theo đuổi đam mê sáng tạo, biến sự tò mò thành động lực cống hiến và từng bước trưởng thành trên con đường phát triển sản phẩm thông minh.',
};

export const skills = [
  { title: 'IELTS 6.0', desc: 'Tiếng Anh giao tiếp và học thuật ở mức khá.' },
  { title: 'Lập trình', desc: 'Kiến thức cơ bản về Python, C và Machine Learning.' },
  { title: 'Làm việc nhóm', desc: 'Phối hợp tốt trong các dự án và bài tập nhóm.' },
  { title: 'Tin học văn phòng', desc: 'Thành thạo Word, Excel.' },
  { title: 'Thái độ làm việc', desc: 'Chăm chỉ, năng nổ, cẩn thận.' },
  { title: 'Tinh thần học hỏi', desc: 'Luôn chủ động tìm tòi kiến thức mới.' },
];

export const projects = [
  {
    title: 'Web hỗ trợ ghi chép cuộc họp online',
    desc: 'Trang web giúp sinh viên và nhân viên văn phòng tự động ghi chép, tóm tắt nội dung các cuộc họp trực tuyến.',
    label: 'Web · AI',
    tags: 'web ai note ghi chép',
  },
  {
    title: 'Web giới thiệu bản thân',
    desc: 'Trang cá nhân giới thiệu thông tin, kĩ năng và dự án — chính là trang bạn đang xem!',
    label: 'Web',
    tags: 'web portfolio giới thiệu bản thân',
  },
  {
    title: 'Web tuyển sinh ngành học',
    desc: 'Trang giới thiệu và tuyển sinh cho ngành học, cung cấp thông tin chương trình đào tạo cho tân sinh viên.',
    label: 'Web',
    tags: 'web tuyển sinh ngành học',
  },
  {
    title: 'Trò chơi Rắn săn mồi & Cờ vua',
    desc: 'Xây dựng hai trò chơi kinh điển: rắn săn mồi và cờ vua, rèn luyện tư duy logic khi lập trình.',
    label: 'Game',
    tags: 'game rắn cờ vua',
  },
];

export const projectFilters = [
  { tag: 'all', label: 'Tất cả' },
  { tag: 'web', label: 'Web' },
  { tag: 'ai', label: 'AI' },
  { tag: 'game', label: 'Game' },
];

export const hobbies = [
  { icon: '🎬', text: 'Xem phim hành động' },
  { icon: '📚', text: 'Đọc sách trinh thám & công nghệ' },
  { icon: '🍳', text: 'Nấu ăn' },
  { icon: '🏊', text: 'Đi bơi' },
];

export const contactInfo = [
  '👤 Bùi Ánh Quyên',
  '📞 0358 058 958',
  '🎓 Học viện Công nghệ Bưu chính Viễn thông',
  '📍 Đông Anh, Hà Nội',
];
