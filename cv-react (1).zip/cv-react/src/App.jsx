import { useEffect, useState } from 'react';
import {
  navItems, defaultAvatar, profile, skills, projects,
  projectFilters, hobbies, contactInfo,
} from './data.js';
import Header from './components/Header.jsx';
import Hero from './components/Hero.jsx';
import Section from './components/Section.jsx';
import SkillCard from './components/SkillCard.jsx';
import Projects from './components/Projects.jsx';
import Hobbies from './components/Hobbies.jsx';
import Contact from './components/Contact.jsx';
import Footer from './components/Footer.jsx';

const softBg = { background: 'var(--bg-soft)', borderTop: '1px solid var(--border)' };

export default function App() {
  const [theme, setTheme] = useState(() => {
    try { return localStorage.getItem('quyen-theme') || 'light'; } catch (e) { return 'light'; }
  });

  useEffect(() => {
    const root = document.documentElement;
    if (theme === 'dark') root.setAttribute('data-theme', 'dark');
    else root.removeAttribute('data-theme');
    try { localStorage.setItem('quyen-theme', theme); } catch (e) {}
  }, [theme]);

  return (
    <>
      <Header items={navItems} theme={theme} onToggleTheme={() => setTheme(theme === 'dark' ? 'light' : 'dark')} />
      <Hero profile={profile} defaultAvatar={defaultAvatar} />

      <Section id="skills" title="Kĩ năng" subtitle="Những gì mình đã và đang rèn luyện">
        <div className="skills-grid">
          {skills.map((s) => <SkillCard key={s.title} title={s.title} desc={s.desc} />)}
        </div>
      </Section>

      <Section
        id="projects"
        title="Dự án"
        subtitle="Một vài sản phẩm mình đã thực hiện — gõ từ khóa hoặc chọn thẻ để lọc"
        style={{ ...softBg, borderBottom: '1px solid var(--border)' }}
      >
        <Projects projects={projects} filters={projectFilters} />
      </Section>

      <Section id="hobbies" title="Sở thích" subtitle="Những điều mình yêu thích ngoài giờ học">
        <Hobbies hobbies={hobbies} />
      </Section>

      <Section
        id="contact"
        title="Liên hệ với tôi"
        subtitle="Để lại lời nhắn, mình sẽ phản hồi sớm nhất có thể!"
        subClass="contact-note"
        style={softBg}
      >
        <Contact info={contactInfo} />
      </Section>

      <Footer name={profile.name} />
    </>
  );
}
