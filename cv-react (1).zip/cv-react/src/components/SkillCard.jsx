import useReveal from '../useReveal.js';

export default function SkillCard({ title, desc }) {
  const ref = useReveal();
  return (
    <div className="skill-card reveal" ref={ref}>
      <h3>{title}</h3>
      <p>{desc}</p>
    </div>
  );
}
