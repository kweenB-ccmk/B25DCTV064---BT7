import useReveal from '../useReveal.js';

// Component bọc dùng children: tiêu đề + mô tả + nội dung bên trong
export default function Section({ id, title, subtitle, subClass = 'section-sub', style, children }) {
  const titleRef = useReveal();
  const subRef = useReveal();
  return (
    <section id={id} style={style}>
      <div className="wrap">
        <h2 className="section-title reveal" ref={titleRef}>{title}</h2>
        {subtitle && <p className={`${subClass} reveal`} ref={subRef}>{subtitle}</p>}
        {children}
      </div>
    </section>
  );
}
