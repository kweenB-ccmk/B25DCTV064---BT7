import { useRef, useState } from 'react';

export default function Hero({ profile, defaultAvatar }) {
  const inputRef = useRef(null);
  const [avatar, setAvatar] = useState(() => {
    try { return localStorage.getItem('quyen-avatar') || defaultAvatar; } catch (e) { return defaultAvatar; }
  });

  const handleFile = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      setAvatar(ev.target.result);
      try { localStorage.setItem('quyen-avatar', ev.target.result); } catch (err) {}
    };
    reader.readAsDataURL(file);
  };

  return (
    <section className="hero" id="about">
      <div className="wrap hero-grid">
        <div className="avatar-wrap">
          <img id="avatarImg" src={avatar} alt={`Ảnh đại diện ${profile.name}`} onClick={() => inputRef.current.click()} />
          <span className="avatar-hint">Nhấn để đổi ảnh</span>
          <input type="file" accept="image/*" style={{ display: 'none' }} ref={inputRef} onChange={handleFile} />
        </div>
        <div>
          <h1>Xin chào, mình là Quyên!</h1>
          <p className="role sans">{profile.role}</p>
          <ul className="facts">
            {profile.facts.map((f) => <li key={f}>{f}</li>)}
          </ul>
          <p className="bio">{profile.bio}</p>
        </div>
      </div>
    </section>
  );
}
