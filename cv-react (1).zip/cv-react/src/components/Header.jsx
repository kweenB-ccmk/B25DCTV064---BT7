import { useState } from 'react';

export default function Header({ items, theme, onToggleTheme }) {
  const [open, setOpen] = useState(false);
  return (
    <header id="siteHeader" data-open={open}>
      <div className="wrap nav-row">
        <div className="brand">Quyên</div>
        <nav>
          <ul id="navList">
            {items.map((it) => (
              <li key={it.id}>
                <a href={`#${it.id}`} className="nav-link" onClick={() => setOpen(false)}>{it.label}</a>
              </li>
            ))}
          </ul>
        </nav>
        <div className="nav-actions">
          <button id="themeBtn" aria-label="Đổi giao diện sáng/tối" onClick={onToggleTheme}>
            {theme === 'dark' ? '☀️' : '🌙'}
          </button>
          <button id="hamburger" aria-label="Mở menu" onClick={() => setOpen(!open)}>
            <span></span><span></span><span></span>
          </button>
        </div>
      </div>
    </header>
  );
}
