import { useState } from 'react';
import useReveal from '../useReveal.js';

function ProjectCard({ title, desc, label }) {
  const ref = useReveal();
  return (
    <div className="proj-card reveal" ref={ref}>
      <h3>{title}</h3>
      <p>{desc}</p>
      <span className="proj-tag">{label}</span>
    </div>
  );
}

export default function Projects({ projects, filters }) {
  const [query, setQuery] = useState('');
  const [activeTag, setActiveTag] = useState('all');

  const q = query.trim().toLowerCase();
  const visible = projects.filter((p) => {
    const text = `${p.title} ${p.desc} ${p.label} ${p.tags}`.toLowerCase();
    const matchesTag = activeTag === 'all' || p.tags.includes(activeTag);
    return matchesTag && (q === '' || text.includes(q));
  });

  return (
    <>
      <div className="filter-row">
        <input
          type="text"
          id="projSearch"
          placeholder="Tìm dự án theo từ khóa hoặc tag..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
        {filters.map((f) => (
          <button
            key={f.tag}
            className={`tag-btn${activeTag === f.tag ? ' active' : ''}`}
            onClick={() => setActiveTag(f.tag)}
          >
            {f.label}
          </button>
        ))}
      </div>
      <div className="proj-grid">
        {visible.map((p) => <ProjectCard key={p.title} {...p} />)}
      </div>
      {visible.length === 0 && <p className="no-result" style={{ display: 'block' }}>Không tìm thấy dự án phù hợp.</p>}
    </>
  );
}
