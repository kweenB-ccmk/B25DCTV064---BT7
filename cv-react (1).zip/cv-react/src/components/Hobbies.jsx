import useReveal from '../useReveal.js';

function HobbyCard({ icon, text }) {
  const ref = useReveal();
  return (
    <div className="hobby-card reveal" ref={ref}>
      <div className="ico">{icon}</div>
      <p>{text}</p>
    </div>
  );
}

export default function Hobbies({ hobbies }) {
  return (
    <div className="hobby-grid">
      {hobbies.map((h) => <HobbyCard key={h.text} {...h} />)}
    </div>
  );
}
