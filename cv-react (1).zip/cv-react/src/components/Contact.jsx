import { useState, useRef } from 'react';
import useReveal from '../useReveal.js';

const empty = { fullname: '', phone: '', email: '', message: '' };

export default function Contact({ info }) {
  const [values, setValues] = useState(empty);
  const [errors, setErrors] = useState({});
  const [toast, setToast] = useState({ show: false, text: '' });
  const timer = useRef(null);
  const formRef = useReveal();
  const infoRef = useReveal();

  const onChange = (e) => setValues({ ...values, [e.target.name]: e.target.value });

  const onSubmit = (e) => {
    e.preventDefault();
    const fullname = values.fullname.trim();
    const errs = {};
    if (fullname.length < 2) errs.fullname = 'Vui lòng nhập họ và tên hợp lệ.';
    if (!/^0\d{9}$/.test(values.phone.trim())) errs.phone = 'Số điện thoại phải gồm 10 số, bắt đầu bằng 0.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email.trim())) errs.email = 'Email không đúng định dạng.';
    if (values.message.trim().length < 5) errs.message = 'Lời nhắn cần ít nhất 5 kí tự.';
    setErrors(errs);

    if (Object.keys(errs).length === 0) {
      setToast({ show: true, text: `Đã gửi tin nhắn thành công! Cảm ơn ${fullname}, mình sẽ phản hồi sớm nhất có thể.` });
      clearTimeout(timer.current);
      timer.current = setTimeout(() => setToast((t) => ({ ...t, show: false })), 4000);
      setValues(empty);
    }
  };

  return (
    <div className="contact-wrap">
      <form id="contactForm" className="reveal" ref={formRef} noValidate onSubmit={onSubmit}>
        <div className="field">
          <label htmlFor="fullname">Họ và tên</label>
          <input type="text" id="fullname" name="fullname" value={values.fullname} onChange={onChange} />
          <span className="err">{errors.fullname}</span>
        </div>
        <div className="field">
          <label htmlFor="phone">Số điện thoại</label>
          <input type="text" id="phone" name="phone" value={values.phone} onChange={onChange} />
          <span className="err">{errors.phone}</span>
        </div>
        <div className="field">
          <label htmlFor="email">Email</label>
          <input type="text" id="email" name="email" value={values.email} onChange={onChange} />
          <span className="err">{errors.email}</span>
        </div>
        <div className="field">
          <label htmlFor="message">Lời nhắn</label>
          <textarea id="message" name="message" rows="4" maxLength="300" value={values.message} onChange={onChange} />
          <div className="charcount">{values.message.length}/300</div>
          <span className="err">{errors.message}</span>
        </div>
        <button type="submit" id="submitBtn">Gửi lời nhắn</button>
        <p id="formStatus"></p>
      </form>

      <div id="toast" className={toast.show ? 'show' : ''}>
        <span className="tick">✅</span><span>{toast.text}</span>
      </div>

      <div className="contact-info reveal" ref={infoRef}>
        <h3>Thông tin liên hệ</h3>
        {info.map((line) => <p key={line}>{line}</p>)}
      </div>
    </div>
  );
}
