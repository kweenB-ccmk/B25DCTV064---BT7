export default function Footer({ name }) {
  return (
    <footer>
      <p>© {new Date().getFullYear()} {name}. Được tạo với ❤ bởi chính mình.</p>
    </footer>
  );
}
